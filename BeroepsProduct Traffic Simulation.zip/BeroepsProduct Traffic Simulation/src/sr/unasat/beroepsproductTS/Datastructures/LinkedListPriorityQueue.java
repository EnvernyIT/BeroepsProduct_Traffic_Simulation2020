package sr.unasat.beroepsproductTS.Datastructures;

import sr.unasat.beroepsproductTS.Models.Voertuig;

public class LinkedListPriorityQueue {
    private LinkedList theList;
    private int Items;
/*
    public LinkedListPriorityQueue(){
        theList = new LinkedList();
        Items = 0;
    }

    public void insertPriorityQueue(Voertuig voertuig){
        theList.insert(voertuig);
        theList.displayPriorityLink(voertuig.getPriority());
    }

    public void removePriority(int i){
        theList.displayPriorityLink(i);
        theList.deletePriority(i);
    }

    public void displayPriorityQueue(int i){
        theList.displayPriorityLink(i);
    }*/
}
